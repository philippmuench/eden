# Samples files to test EDEN

6 fasta files that containing assembled shotgun metagenomic samples from HMP project. Three of them from the nares, 3 from the throat. You may want to use the grouping function to pool these 3 samples together for each group.

# Licences

## FASTA sample data
The Human Microbiome Project Consortium (http://hmpdacc.org/)
A framework for human microbiome research, The Human Microbiome Project Consortium, Nature 2012

## TIGRFAM sample data
Copyright 1995-2014 The J. Craig Venter Institute. All rights
reserved.

This data is provided "AS IS". The J. Craig Venter Institute
makes no Representation or warranty, express or
implied, including without limitation any warranties of
merchantability or fitness for a particular purpose, associated
with the receipt or use of this data.

This database is free; you can redistribute it and/or modify it under
the terms of the GNU Library General Public License as published by
the Free Software Foundation; either version 2 of the License, or (at
your option) any later version.

In summary, you are free to redistribute *verbatim* copies of TIGRFAMs
or any TIGRFAMs files in any way you like, so long as your copy
of TIGRFAMs retains our copyright notice and the GNU license. You may also
make *modified* copies of TIGRFAMs and distribute them, but your derivative
database must be freely distributed under the GNU LGPL. Proprietary
modification of the TIGRFAMs database is prohibited, except by a separate
formal licensing agreement from the J. Craig Venter Institute.

